import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const DEMO_MODE = import.meta.env.VITE_DEMO_MODE === "true";

    useEffect(() => {
        checkAuth();
    }, []);

    const checkAuth = async () => {
        try {
            // Using backend URL from env or defaulting to 5000 if local
            const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";
            const res = await fetch(`${API_URL}/auth/me`, {
                credentials: "include", // Important for cookies (sessions)
                headers: {
                    "Content-Type": "application/json"
                }
            });
            const data = await res.json();
            if (data.authenticated) {
                setUser(data.user);
            } else {
                setUser(null);
            }
        } catch (error) {
            console.error("Auth check failed", error);
            setUser(null);
        } finally {
            setLoading(false);
        }
    };

    const login = async (provider) => {
        const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";
        if (DEMO_MODE || provider === "demo") {
            const res = await fetch(`${API_URL}/auth/demo-login`, {
                method: "POST",
                credentials: "include",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name: "NRB Demo User", email: "demo@nrb.local" })
            });
            if (res.ok) await checkAuth();
            return;
        }
        window.location.href = `${API_URL}/auth/${provider}`;
    };

    const logout = async () => {
        const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";
        setUser(null);
        if (DEMO_MODE) {
            await fetch(`${API_URL}/auth/demo-logout`, { method: "POST", credentials: "include" });
            return;
        }
        window.location.href = `${API_URL}/auth/zitadel/logout`;
    };

    return (
        <AuthContext.Provider value={{ user, loading, login, logout, checkAuth }}>
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => useContext(AuthContext);
