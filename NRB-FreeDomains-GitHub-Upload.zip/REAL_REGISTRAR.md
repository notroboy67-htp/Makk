# NRB Real Registrar Integration

The project now supports **real domain availability checks and registrations through Openprovider's REST API**.

Official API documentation: https://docs.openprovider.com/doc/all

## Configure

Set these variables on the backend host (never expose them as VITE_ variables):

```env
OPENPROVIDER_USERNAME=your_reseller_username
OPENPROVIDER_PASSWORD=your_reseller_password
OPENPROVIDER_LOGIN_IP=0.0.0.0
OPENPROVIDER_BASE_URL=https://api.openprovider.eu/v1beta
```

The Openprovider account must have API access and sufficient balance. Availability is checked with `/domains/check`; registration uses `/domains` after creating a customer handle.

## Run

```bash
npm install
npm run server
```

In another terminal:

```bash
npm run dev
```

## API

### Check
`POST /domains/check`

```json
{"domains":["example.com","example.net"]}
```

### Register
`POST /domains/register` (authenticated)

```json
{
  "domain":"example.com",
  "period":1,
  "autorenew":"default",
  "contact":{
    "firstName":"John",
    "lastName":"Doe",
    "email":"john@example.com",
    "country":"IN",
    "street":"Main Road",
    "number":"1",
    "city":"Anantapur",
    "state":"Andhra Pradesh",
    "zipcode":"515001",
    "phone":"+919999999999"
  }
}
```

**Important:** this can create a real registration and charge the registrar account. Use the registrar's test/sandbox environment first where available, and add payment/checkout controls before exposing registration to public users.
