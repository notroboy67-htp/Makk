# NRB Free Domains — Port 5000

The project is configured so the **built website and backend API use port 5000**.

## Production / Codespaces

```bash
npm install
npm run start
```

Then open the forwarded Codespaces port **5000**.

`npm run start` builds the React app into `dist/` and starts the Node server. The same server serves the website and API from port 5000.

## Rebuild after code changes

```bash
npm run build
npm run serve
```

## Development frontend

```bash
npm run dev
```

This runs Vite on port 5000, but the backend API is not started by this command. For the complete one-port deployment, use `npm run start`.
