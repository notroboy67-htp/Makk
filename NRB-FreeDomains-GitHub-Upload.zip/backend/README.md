# NRB Free Domains Demo API

Run `npm run server`. This is a local/demo backend using a JSON database. Production needs real authentication, a database, and registrar/DNS provider API credentials.
