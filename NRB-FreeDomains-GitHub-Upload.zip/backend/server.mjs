import http from "node:http";
import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, "data");
const dbFile = join(dataDir, "db.json");
const projectRoot = join(__dirname, "..");
const distDir = join(projectRoot, "dist");
mkdirSync(dataDir, { recursive: true });
if (!existsSync(dbFile)) writeFileSync(dbFile, JSON.stringify({users:{},subdomains:[],activity:[]},null,2));
const readDB=()=>JSON.parse(readFileSync(dbFile,"utf8"));
const saveDB=db=>writeFileSync(dbFile,JSON.stringify(db,null,2));
const reserved=new Set(["www","mail","admin","api","ns1","ns2","ns3","ftp","support","status","dashboard"]);
const roots=["indevs.in","sryze.cc","ryzedns.org","nx.kg","ryzn.pro"];

const OPENPROVIDER_BASE = process.env.OPENPROVIDER_BASE_URL || "https://api.openprovider.eu/v1beta";
let openproviderToken = null;
let openproviderTokenExpiresAt = 0;

async function openproviderAuth() {
  if (!process.env.OPENPROVIDER_USERNAME || !process.env.OPENPROVIDER_PASSWORD) {
    throw new Error("Openprovider credentials are not configured");
  }
  if (openproviderToken && Date.now() < openproviderTokenExpiresAt) return openproviderToken;
  const r = await fetch(`${OPENPROVIDER_BASE}/auth/login`, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({
      username: process.env.OPENPROVIDER_USERNAME,
      password: process.env.OPENPROVIDER_PASSWORD,
      ip: process.env.OPENPROVIDER_LOGIN_IP || "0.0.0.0"
    })
  });
  const data = await r.json().catch(()=>({}));
  if (!r.ok || !data?.data?.token) {
    throw new Error(data?.desc || data?.message || "Openprovider authentication failed");
  }
  openproviderToken = data.data.token;
  openproviderTokenExpiresAt = Date.now() + 50 * 60 * 1000;
  return openproviderToken;
}

async function openproviderRequest(path, options={}) {
  const token = await openproviderAuth();
  const r = await fetch(`${OPENPROVIDER_BASE}${path}`, {
    ...options,
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });
  const data = await r.json().catch(()=>({}));
  if (!r.ok || (typeof data.code === "number" && data.code !== 0 && data.code !== 20001)) {
    const err = new Error(data?.desc || data?.message || `Openprovider request failed (${r.status})`);
    err.provider = data;
    err.status = r.status;
    throw err;
  }
  return data;
}

function splitDomain(full) {
  const value = String(full || "").trim().toLowerCase();
  if (!/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(value)) {
    throw new Error("Invalid domain name");
  }
  const parts = value.split(".");
  return {name: parts.slice(0,-1).join("."), extension: parts.at(-1)};
}

function contactPayload(c={}) {
  const name = String(c.firstName || "").trim();
  const last = String(c.lastName || "").trim();
  const email = String(c.email || "").trim();
  const country = String(c.country || "").trim().toUpperCase();
  const street = String(c.street || "").trim();
  const number = String(c.number || "1").trim();
  const city = String(c.city || "").trim();
  const zipcode = String(c.zipcode || "").trim();
  const state = String(c.state || "").trim();
  const phone = String(c.phone || "").replace(/[^\d+]/g,"");
  if (!name || !last || !email || !country || !street || !city || !zipcode || !phone) {
    throw new Error("Complete registrant contact details are required");
  }
  const digits = phone.replace(/\D/g,"");
  const countryCode = phone.startsWith("+") ? `+${digits.slice(0, Math.max(1, digits.length-10))}` : (c.countryCode || "+91");
  const subscriber = digits.slice(-10);
  return {
    address:{street, number, city, zipcode, state, country},
    email,
    name:{first_name:name,last_name:last,full_name:`${name} ${last}`,initials:`${name[0]}${last[0]}`},
    phone:{country_code:countryCode, area_code:"", subscriber_number:subscriber}
  };
}
const id=()=>Math.random().toString(36).slice(2)+Date.now().toString(36);
function cookies(req){return Object.fromEntries((req.headers.cookie||"").split(";").filter(Boolean).map(v=>{const i=v.indexOf("=");return [v.slice(0,i).trim(),decodeURIComponent(v.slice(i+1).trim())]}))}
function user(req,db){const c=cookies(req);return c.demo_user?db.users[c.demo_user]:null}
function send(res,status,body,extra={}){res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":res.reqOrigin||"*","Access-Control-Allow-Credentials":"true",...extra});res.end(JSON.stringify(body))}

function serveStatic(res, pathname) {
  if (!existsSync(distDir)) return false;
  let relative = pathname === "/" ? "/index.html" : pathname;
  if (relative.includes("..")) return false;
  let file = join(distDir, relative.replace(/^\//, ""));
  try {
    let st = statSync(file);
    if (!st.isFile()) return false;
  } catch {
    // SPA fallback for client-side routes.
    file = join(distDir, "index.html");
    try { if (!statSync(file).isFile()) return false; } catch { return false; }
  }
  const ext = file.split(".").pop().toLowerCase();
  const types = { html:"text/html", js:"text/javascript", mjs:"text/javascript", css:"text/css", json:"application/json", svg:"image/svg+xml", png:"image/png", jpg:"image/jpeg", jpeg:"image/jpeg", webp:"image/webp", ico:"image/x-icon", txt:"text/plain", woff:"font/woff", woff2:"font/woff2" };
  res.writeHead(200,{"Content-Type":`${types[ext]||"application/octet-stream"}; charset=utf-8`});
  res.end(readFileSync(file));
  return true;
}
async function body(req){let b="";for await(const c of req)b+=c;try{return b?JSON.parse(b):{}}catch{return{}}}
const server=http.createServer(async(req,res)=>{
 res.reqOrigin = req.headers.origin || "*";
 if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":req.headers.origin||"*","Access-Control-Allow-Credentials":"true","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"GET,POST,PATCH,DELETE,OPTIONS"});return res.end()}
 const url=new URL(req.url,"http://localhost:5000"),path=url.pathname;let db=readDB();
 try{
  if(path==="/auth/me"){const u=user(req,db);return send(res,200,{authenticated:!!u,user:u||null})}
  if(path==="/auth/email-login"&&req.method==="POST"){
    const b=await body(req);
    const email=String(b.email||"").trim().toLowerCase();
    const name=String(b.name||email.split("@")[0]||"NRB User").trim().slice(0,80);
    if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) return send(res,400,{error:"A valid email address is required"});
    if(!db.users[email]) db.users[email]={id:`email-${id()}`,name,email,githubVerified:true,domainLimit:10,sryzeDomainsLimit:10,ryzeDnsDomainsLimit:10,nxKgDomainsLimit:10,ryznProDomainsLimit:10,domainsCount:0};
    else db.users[email].githubVerified=true;
    saveDB(db);
    return send(res,200,{authenticated:true,user:db.users[email]},{"Set-Cookie":`demo_user=${encodeURIComponent(email)}; Path=/; HttpOnly; SameSite=Lax`});
  }
  if(path==="/auth/demo-login"&&req.method==="POST"){const b=await body(req),email=b.email||"demo@nrb.local";if(!db.users[email])db.users[email]={id:"demo-user",name:b.name||"NRB Demo User",email,githubVerified:true,domainLimit:10,sryzeDomainsLimit:10,ryzeDnsDomainsLimit:10,nxKgDomainsLimit:10,ryznProDomainsLimit:10,domainsCount:0};saveDB(db);return send(res,200,{authenticated:true,user:db.users[email]},{"Set-Cookie":`demo_user=${encodeURIComponent(email)}; Path=/; HttpOnly; SameSite=Lax`})}
  if((path==="/auth/demo-logout"&&req.method==="POST")||(path.endsWith("/logout")&&req.method==="GET")){return send(res,200,{ok:true},{"Set-Cookie":"demo_user=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"})}

  if(path==="/registrar/status"&&req.method==="GET"){
    return send(res,200,{provider:"openprovider",configured:!!(process.env.OPENPROVIDER_USERNAME&&process.env.OPENPROVIDER_PASSWORD),environment:OPENPROVIDER_BASE});
  }
  if(path==="/domains/check"&&req.method==="POST"){
    const b=await body(req);
    const domains=Array.isArray(b.domains)?b.domains.map(String):[String(b.domain||"")];
    if(!domains.length || domains.some(d=>!d)) return send(res,400,{error:"domain or domains is required"});
    try{
      const parsed=domains.map(splitDomain);
      const result=await openproviderRequest("/domains/check",{method:"POST",body:JSON.stringify({
        domains:parsed.map(x=>({name:x.name,extension:x.extension})),
        with_price:true
      })});
      return send(res,200,result.data||result);
    }catch(e){return send(res,e.status||502,{error:e.message,provider:e.provider||null});}
  }
  // Serve the built React application from the same port as the API.
  if (req.method === "GET" && !path.startsWith("/auth/") && !path.startsWith("/domains/") && !path.startsWith("/subdomains") && !path.startsWith("/registrar/")) {
    if (serveStatic(res, path)) return;
  }
  const u=user(req,db);if(!u)return send(res,401,{error:"Authentication required"});

  if(path==="/domains/register"&&req.method==="POST"){
    const b=await body(req);
    try{
      const parsed=splitDomain(b.domain);
      const contact=contactPayload(b.contact||{});
      // Create a provider customer/contact handle for the registrant.
      const customer=await openproviderRequest("/customers",{method:"POST",body:JSON.stringify(contact)});
      const handle=customer?.data?.handle;
      if(!handle) throw new Error("Registrar did not return a customer handle");
      const period=String(Math.max(1,Math.min(10,Number(b.period||1))));
      const order=await openproviderRequest("/domains",{method:"POST",body:JSON.stringify({
        admin_handle:handle,billing_handle:handle,owner_handle:handle,tech_handle:handle,
        domain:{name:parsed.name,extension:parsed.extension},
        period,autorenew:b.autorenew==="on"?"on":"default",
        ...(Array.isArray(b.nameServers)&&b.nameServers.length?{name_servers:b.nameServers.map(name=>({name}))}: {})
      })});
      const fullDomain=`${parsed.name}.${parsed.extension}`;
      db.activity.push({id:id(),userId:u.id,action:"real-domain-registered",domain:fullDomain,createdAt:new Date().toISOString(),provider:"openprovider"});
      saveDB(db);
      return send(res,201,{ok:true,provider:"openprovider",domain:fullDomain,order:order.data||order});
    }catch(e){return send(res,e.status||502,{error:e.message,provider:e.provider||null});}
  }
  if(path==="/subdomains"&&req.method==="GET")return send(res,200,{subdomains:db.subdomains.filter(x=>x.userId===u.id&&!x.deletedAt)});
  if(path==="/subdomains/activity")return send(res,200,{activity:db.activity.filter(x=>x.userId===u.id).slice(-100).reverse()});
  if(path.startsWith("/subdomains/check/")){const name=decodeURIComponent(path.split("/").pop()).toLowerCase(),domain=url.searchParams.get("domain")||"indevs.in";const valid=/^[a-z0-9](?:[a-z0-9-]{1,61}[a-z0-9])?$/.test(name),taken=reserved.has(name)||db.subdomains.some(x=>x.name===name&&x.domain===domain&&!x.deletedAt);return send(res,200,{available:valid&&!taken,message:!valid?"Invalid domain name":taken?"Domain is already taken":""})}
  if(path==="/subdomains"&&req.method==="POST"){const b=await body(req),name=String(b.name||"").toLowerCase(),domain=b.domain||"indevs.in";if(!roots.includes(domain))return send(res,400,{error:"Unsupported root domain"});if(!/^[a-z0-9](?:[a-z0-9-]{1,61}[a-z0-9])?$/.test(name)||reserved.has(name)||db.subdomains.some(x=>x.name===name&&x.domain===domain&&!x.deletedAt))return send(res,409,{error:"Domain is unavailable"});const item={id:id(),userId:u.id,name,domain,recordType:b.recordType||"A",recordValue:b.recordValue||"127.0.0.1",createdAt:new Date().toISOString(),expiresAt:new Date(Date.now()+31536000000).toISOString(),deletedAt:null};db.subdomains.push(item);db.activity.push({id:id(),userId:u.id,action:"registered",domain:`${name}.${domain}`,createdAt:new Date().toISOString()});u.domainsCount=(u.domainsCount||0)+1;saveDB(db);return send(res,201,item)}
  const m=path.match(/^\/subdomains\/([^/]+)$/);if(m){const item=db.subdomains.find(x=>x.id===m[1]&&x.userId===u.id);if(!item)return send(res,404,{error:"Domain not found"});if(req.method==="DELETE"){item.deletedAt=new Date().toISOString();u.domainsCount=Math.max(0,(u.domainsCount||1)-1);saveDB(db);return send(res,200,{ok:true})}if(req.method==="PATCH"){const b=await body(req);if(b.recordType)item.recordType=b.recordType;if(b.recordValue!==undefined)item.recordValue=b.recordValue;saveDB(db);return send(res,200,item)}}
  if (req.method === "GET" && serveStatic(res, path)) return;
  return send(res,404,{error:"Not found"});
 }catch(e){console.error(e);return send(res,500,{error:"Server error"})}
});
server.listen(5000,"0.0.0.0",()=>console.log("NRB Free Domains website + API: http://localhost:5000"));
