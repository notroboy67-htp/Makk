import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        checkAuth();
    }, []);

    const checkAuth = async () => {
        try {
            // Using backend URL from env or defaulting to 5000 if local
            const API_URL = import.meta.env.VITE_API_URL || window.location.origin;
            const res = await fetch(`${API_URL}/auth/me`, {
                credentials: "include", // Important for cookies (sessions)
                headers: {
                    "Content-Type": "application/json"
                }
            });
            const data = await res.json();
            if (data.authenticated) {
                setUser(data.user);
            } else {
                setUser(null);
            }
        } catch (error) {
            console.error("Auth check failed", error);
            setUser(null);
        } finally {
            setLoading(false);
        }
    };

    const login = async (email = "demo@nrb.local", name = "NRB User") => {
        const API_URL = import.meta.env.VITE_API_URL || window.location.origin;
        const res = await fetch(`${API_URL}/auth/email-login`, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, name })
        });
        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            throw new Error(data.error || "Unable to sign in");
        }
        await checkAuth();
    };

    const continueToNRB = () => login("guest@nrb.local", "NRB Guest");

    const logout = async () => {
        const API_URL = import.meta.env.VITE_API_URL || window.location.origin;
        setUser(null);
        await fetch(`${API_URL}/auth/demo-logout`, { method: "POST", credentials: "include" });
    };

    return (
        <AuthContext.Provider value={{ user, loading, login, continueToNRB, logout, checkAuth }}>
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => useContext(AuthContext);
