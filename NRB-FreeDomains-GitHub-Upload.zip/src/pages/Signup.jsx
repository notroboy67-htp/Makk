import { ShieldCheck, Mail, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { useAuth } from "../context/auth-context";
import { Header } from "../components/header";

export default function Signup() {
    const { login } = useAuth();
    const [email, setEmail] = useState("");
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");

    const handleSignup = async (e) => {
        e?.preventDefault();
        const value = email.trim().toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) { setError("Enter a valid email address."); return; }
        try {
            setBusy(true);
            setError("");
            await login(value, value.split("@")[0] || "NRB User");
            window.location.href = "/dashboard";
        } catch (err) {
            setError(err.message);
        } finally {
            setBusy(false);
        }
    };

    return (
        <>
            <Header />
            <div className="min-h-screen flex flex-col items-center justify-center bg-transparent px-4 py-10" style={{ paddingTop: 'calc(4rem + var(--incident-height, 0px) + 2.5rem)' }}>
                <div className="w-full max-w-md bg-white dark:bg-transparent rounded-[24px] border border-slate-200/80 dark:border-white/5 p-8 md:p-10 relative overflow-hidden">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[80%] h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent dark:via-white/10"></div>

                    {/* Header */}
                    <div className="mb-8 flex items-start justify-between">
                        <div>
                            <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-1">Create Account</h1>
                            <p className="text-slate-500 dark:text-slate-400 text-sm">Sign up to register your free subdomains</p>
                        </div>
                        <Link to="/" className="flex items-center gap-2 shrink-0">
                            <img src="/nrb_logo_black.png" alt="NRB Logo" className="h-8 w-auto dark:hidden" />
                            <img src="/nrb_logo_white.png" alt="NRB Logo" className="h-8 w-auto hidden dark:block" />
                        </Link>
                    </div>

                    {error && <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm">{error}</div>}
                    <form onSubmit={handleSignup} className="space-y-4">
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200">Email address</label>
                        <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/5 text-slate-900 dark:text-white outline-none" />
                        </div>
                        <button type="submit" disabled={busy} className="w-full flex items-center justify-center gap-3 bg-black text-white dark:bg-white dark:text-black py-3 rounded-xl font-medium text-sm hover:bg-neutral-800 dark:hover:bg-slate-200 transition-all duration-300 shadow-sm disabled:opacity-60">
                            {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5" />}
                            {busy ? "Creating account..." : "Create with Email"}
                        </button>
                    </form>
                    <p className="mt-6 text-center text-xs text-slate-400 dark:text-slate-500">No GitHub authorization is required.</p>

                    <p className="mt-6 text-center text-xs text-slate-400 dark:text-slate-500">
                        You'll be redirected to create an account or sign in securely via NRB SSO.
                    </p>
                </div>

                <div className="mt-6 text-center text-sm text-slate-500 dark:text-slate-400">
                    Already have an account? <Link to="/login" className="text-slate-900 dark:text-white font-medium hover:underline">Sign In</Link>
                </div>

                <p className="mt-8 text-xs text-slate-400">
                    &copy; 2026 NRB Free Domains
                </p>
            </div>
        </>
    );
}
