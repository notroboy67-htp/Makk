# 🌐 Claim Free Domains — Powered by NRB Free Domains

**Join our Discord:** https://discord.gg/wr7s97cfM7

---

**NRB Free Domains** runs **Multiple** Domains Names, a free managed subdomain service for developers, students, and open-source communities.

Claim a domain and point it to any hosting provider or your own infrastructure. You get full ownership and complete control.

**Build fast. Deploy freely. No lock-in.**

---

## Why US?

Our goal is simple: remove cost and complexity from getting online.

- Free managed domains  
- Works with any hosting or DNS provider  
- Built for students, developers, and OSS projects  
- Transparent, community-driven, and reliable  

---

## 🌍 Available Domains

- **.indevs.in**
- **.sryze.cc**
- **.ryzedns.org**
- **.nx.kg**
*More extensions coming soon.*

---
## 🏗️ Architecture
We believe transparency should be demonstrated, not advertised. That's why we're publicly sharing the infrastructure and systems behind NRB Free Domains and NRB DNS, and we're fully open to feedback, questions, and scrutiny from the community.
![NRB Architecture](architecture.png)

## 🌐 DNS Infrastructure

NRB Free Domains Namespaces are backed by globally distributed name servers for reliability and low latency:

- **ns1.nrb.com** — Primary DNS server (New York City, USA)
- **ns2.nrb.com** — Secondary DNS Server (Nuremberg, Germany)  
- **ns3.nrb.com** — Secondary DNS server (Hyderabad, India)

---
## ❤️ Sponsors

Supported by organizations that believe in open-source and developer communities.

<div align="center">

<img src="/public/Cloudflare_Logo.png" alt="Cloudflare" height="40" />
&nbsp;&nbsp;&nbsp;
<img src="https://companieslogo.com/img/orig/DOCN_BIG.D-a2c943bc.png" alt="Digital Ocean" height="40" />
&nbsp;&nbsp;&nbsp;
<img src="/public/hetrixtools.png" alt="Hetrix Tools" height="40" />
<img src="https://ca.insight.com/content/dam/insight-web/logos/partner-logos/white/branded-search/1password.png" alt="1Password" height="48" />
&nbsp;&nbsp;&nbsp;

</div>

---

## 🚀 Get Started

**Dashboard:** https://domain.nrb.com   
**GitHub:** https://github.com/nrb/FreeDomains/issues  
**Discord:** https://discord.gg/wr7s97cfM7   
**Support:** support@nrb.com  
## Service Status

Live status and incident updates for all NRB services: https://status.nrb.com

---

📧 **Abuse reports:** reportabuse@nrb.com

---

<div align="center">

<img src="/public/nrb_logo_white.png" alt="NRB Free Domains" height="48" />

<br />

<strong>NRB Free Domains — a project by NRB.</strong>

</div>
