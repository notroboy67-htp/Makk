# NRB Free Domains

This is the supplied FreeDomains project reworked as an NRB Free Domains project.

## Local demo

Terminal 1:
```bash
npm install
npm run server
```

Terminal 2:
```bash
npm run dev
```

Open the Vite URL, normally `http://localhost:5173`.

The included demo API supports login, availability checks, registration, domain listing/deletion, DNS record updates, and activity history.

**Important:** this demo does not register domains with a real registrar or DNS provider. Real provisioning requires provider API credentials and a production backend.


## NRB No-Login Mode
The public UI opens directly to the dashboard. Email/GitHub login and signup UI are disabled. A guest session is created automatically for domain management.
