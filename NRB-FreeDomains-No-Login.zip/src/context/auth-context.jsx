import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        checkAuth();
    }, []);

    const checkAuth = async () => {
        try {
            // Using backend URL from env or defaulting to 5000 if local
            const API_URL = import.meta.env.VITE_API_URL || window.location.origin;
            const res = await fetch(`${API_URL}/auth/me`, {
                credentials: "include", // Important for cookies (sessions)
                headers: {
                    "Content-Type": "application/json"
                }
            });
            const data = await res.json();
            if (data.authenticated) {
                setUser(data.user);
            } else {
                // Guest mode: automatically create/use the built-in NRB session.
                // No login, GitHub OAuth, or account creation is required.
                const guest = await fetch(`${API_URL}/auth/demo-login`, {
                    method: "POST",
                    credentials: "include",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email: "guest@nrb.local", name: "NRB Guest" })
                });
                const guestData = await guest.json();
                if (guest.ok && guestData.authenticated) {
                    setUser(guestData.user);
                } else {
                    setUser(null);
                }
            }
        } catch (error) {
            console.error("Auth check failed", error);
            setUser(null);
        } finally {
            setLoading(false);
        }
    };

    // Login/signup are intentionally disabled. NRB runs in guest mode.
    const continueToNRB = async () => {
        await checkAuth();
    };

    const logout = async () => {
        // No public login system; simply restore the guest session.
        await fetch(`${import.meta.env.VITE_API_URL || window.location.origin}/auth/demo-login`, {
            method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: "guest@nrb.local", name: "NRB Guest" })
        });
        await checkAuth();
    };

    return (
        <AuthContext.Provider value={{ user, loading, continueToNRB, logout, checkAuth }}>
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => useContext(AuthContext);
