import { ShieldCheck, Mail, Loader2 } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { useAuth } from "../context/auth-context";
import { Header } from "../components/header";

export default function Login() {
    const { login, continueToNRB } = useAuth();
    const [searchParams] = useSearchParams();
    const error = searchParams.get('error');
    const [errorBanner, setErrorBanner] = useState(null);
    const [email, setEmail] = useState("");
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        if (error) {
            let title = "Login Failed";
            let description = "An unknown error occurred. Please try again.";

            switch (error) {
                case 'banned':
                    title = "Account Suspended";
                    description = "Your account has been banned for violating our terms.";
                    break;
                case 'oidc_failed':
                    title = "Sign-in Failed";
                    description = "We couldn't complete sign-in with NRB. Please try again.";
                    break;
                case 'server_error':
                    title = "Server Error";
                    description = "Something went wrong on our end. Please try later.";
                    break;
                default:
                    description = error;
                    break;
            }

            setErrorBanner({ title, description });
        }
    }, [error]);

    const handleLogin = async (e) => {
        e?.preventDefault();
        const value = email.trim().toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
            setErrorBanner({ title: "Enter your email", description: "Please enter a valid email address to continue." });
            return;
        }
        try {
            setBusy(true);
            await login(value, value.split("@")[0] || "NRB User");
            window.location.href = "/dashboard";
        } catch (err) {
            setErrorBanner({ title: "Sign-in failed", description: err.message });
        } finally {
            setBusy(false);
        }
    };

    return (
        <>
            <Header />
            <div className="min-h-screen flex flex-col items-center justify-center bg-transparent px-4 py-10" style={{ paddingTop: 'calc(4rem + var(--incident-height, 0px) + 2.5rem)' }}>
                <div className="w-full max-w-md bg-white dark:bg-transparent rounded-[24px] border border-slate-200/80 dark:border-white/5 p-8 md:p-10 relative overflow-hidden">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[80%] h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent dark:via-white/10"></div>

                    {/* Header */}
                    <div className="mb-8 flex items-start justify-between">
                        <div>
                            <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-1">Welcome back</h1>
                            <p className="text-slate-500 dark:text-slate-400 text-sm">Sign in to manage your subdomains</p>
                        </div>
                        <Link to="/" className="flex items-center gap-2 shrink-0">
                            <img src="/nrb_logo_black.png" alt="NRB Logo" className="h-8 w-auto dark:hidden" />
                            <img src="/nrb_logo_white.png" alt="NRB Logo" className="h-8 w-auto hidden dark:block" />
                        </Link>
                    </div>

                    {/* Error Banner */}
                    {errorBanner && (
                        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-left">
                            <div className="flex items-start gap-3">
                                <div className="flex-1">
                                    <h3 className="font-bold text-red-900 mb-1 text-sm">{errorBanner.title}</h3>
                                    <p className="text-xs text-red-800">{errorBanner.description}</p>
                                </div>
                                <button
                                    onClick={() => setErrorBanner(null)}
                                    aria-label="Dismiss error"
                                    className="text-red-900 hover:text-red-700 font-bold text-xl leading-none"
                                >×</button>
                            </div>
                        </div>
                    )}

                    <button
                        type="button"
                        onClick={async () => {
                            try {
                                setBusy(true);
                                await continueToNRB();
                                window.location.href = "/dashboard";
                            } catch (err) {
                                setErrorBanner({ title: "Unable to continue", description: err.message });
                            } finally {
                                setBusy(false);
                            }
                        }}
                        disabled={busy}
                        className="w-full mb-4 flex items-center justify-center gap-3 bg-black text-white dark:bg-white dark:text-black py-3 rounded-xl font-bold text-sm hover:bg-neutral-800 dark:hover:bg-slate-200 transition-all duration-300 shadow-sm disabled:opacity-60"
                    >
                        <ShieldCheck className="w-5 h-5" />
                        Continue to NRB
                    </button>

                    <div className="flex items-center gap-3 my-5 text-xs text-slate-400">
                        <div className="h-px flex-1 bg-slate-200 dark:bg-white/10" />
                        <span>OR</span>
                        <div className="h-px flex-1 bg-slate-200 dark:bg-white/10" />
                    </div>

                    <form onSubmit={handleLogin} className="space-y-4">
                        <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200">Email address</label>
                        <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="you@example.com"
                                autoComplete="email"
                                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/5 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-black/10 dark:focus:ring-white/20"
                            />
                        </div>
                        <button
                            type="submit"
                            disabled={busy}
                            className="w-full flex items-center justify-center gap-3 bg-black text-white dark:bg-white dark:text-black py-3 rounded-xl font-medium text-sm hover:bg-neutral-800 dark:hover:bg-slate-200 transition-all duration-300 shadow-sm disabled:opacity-60"
                        >
                            {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5" />}
                            {busy ? "Signing in..." : "Continue with Email"}
                        </button>
                    </form>

                    <div className="mt-6 text-center space-y-3">
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                            Don't have an account? <Link to="/signup" className="font-bold text-slate-900 dark:text-white hover:underline">Create Account</Link>
                        </p>
                        <p className="text-xs text-slate-400 dark:text-slate-500">
                            No GitHub authorization. Your NRB account is created locally using your email.
                        </p>
                    </div>
                </div>

                <div className="mt-6 text-center text-sm text-slate-500 dark:text-slate-400">
                    Need help? <a href="https://discord.gg/wr7s97cfM7" target="_blank" rel="noopener noreferrer" className="text-slate-900 dark:text-white font-medium hover:underline">Join our Discord</a> or email <a href="mailto:support@nrb.com" className="text-slate-900 dark:text-white font-medium hover:underline">support@nrb.com</a>
                </div>

                <p className="mt-8 text-xs text-slate-400">
                    &copy; 2026 NRB Free Domains
                </p>
            </div>
        </>
    );
}
